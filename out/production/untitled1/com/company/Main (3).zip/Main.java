package com.company;
import java.util.*;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] array = new int[4];
        System.out.println("enter the numbers: ");
        for (int i = 0; i < array.length; i++) {
            array[i] = sc.nextInt();
        }squaredArray(array);
    }public static int[]squaredArray(int[] array){
        int[] Array=new int[4];
        for (int i = 0; i < Array.length; i++) {
            Array[i]= array[i]*array[i];}
        for (int i = 0; i < Array.length; i++) {
            System.out.println(Array[i]+ " ");}
        return Array;}}









