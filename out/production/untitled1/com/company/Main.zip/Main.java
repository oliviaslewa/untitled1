package com.company;
import java.util.*;
public class Main {
    public static void main(String[]args){
        Scanner sc=new Scanner(System.in);  //#1
       int[]value=new int[5];
        for (int i = 0; i < value.length; i++) {
            System.out.println("enter the value for no."+ (i+1));
            value[i]=sc.nextInt();}
        for (int i = 0; i < value.length; i++) {
            System.out.println("the value of no." + i +" is "+ value[i]);}}}