package com.company;
import java.util.*;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] value = new int[5];        //activity1
        for (int i = 0; i < value.length; i++) {
            System.out.println("enter the value for no." + (i + 1));
            value[i] = sc.nextInt();
        }
        for (int i = 0; i < value.length; i++) {
            System.out.println("the value of no." + i + " is " + value[i]);
        }
        System.out.println("---------------------------------------");
        int[] array = new int[3];     //activity2
        System.out.println("enter the numbers: ");
        for (int i = 0; i < array.length; i++) {
            array[i] = sc.nextInt();
        }
        System.out.println("sum of array is " + arraySum(array));
    }
         public static int arraySum( int []Array) {
             int sum = 0;
             for (int i = 0; i < Array.length; i++) {
                 sum = sum + Array[i];}
             return sum;}
}
